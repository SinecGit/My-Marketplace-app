import json

from django.contrib.auth.password_validation import validate_password
from django.http import HttpResponse
from rest_framework.response import Response
from rest_framework.views import APIView
from django.contrib.auth import authenticate, login, logout, get_user_model
from rest_framework.exceptions import ValidationError

from .models import Profile, Avatar
from .serializers import ProfileSerializer, ChangePasswordSerializer
from api_orders.views import BasketAPIView

User = get_user_model()


class ProfileAPIView(APIView):
    def get(self, request):
        queryset = Profile.objects.get(user=request.user)
        return Response(ProfileSerializer(queryset).data)

    def post(self, request):
        inst_profile = Profile.objects.get(user=request.user)
        inst_profile.fullName = request.data["fullName"]
        inst_profile.email = request.data["email"]
        inst_profile.phone = request.data["phone"]
        inst_profile.save()

        return Response(ProfileSerializer(inst_profile).data)


def avatar_change(request):
    if request.method == "POST":
        new_avatar = Avatar.objects.create(
            src=request.FILES["avatar"], alt=request.FILES["avatar"]
        )
        instance_profile = Profile.objects.get(user=request.user)
        instance_profile.avatar = new_avatar
        instance_profile.save()

    return HttpResponse(status=200)


class ChangePasswordView(APIView):
    def post(self, request):
        user = request.user
        serializer = ChangePasswordSerializer(instance=user, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(request.data)


def signin(request):
    if request.method == "POST":
        body = json.loads(request.body)
        username = body["username"]
        password = body["password"]
        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return HttpResponse(status=200)
        else:
            return HttpResponse(status=500)

    return HttpResponse(status=200)


def signout(request):
    BasketAPIView.clear_basket()
    logout(request)
    return HttpResponse(status=200)


def signup(request):
    if request.method == "POST":
        body = json.loads(request.body)

        if validate_password(body["password"]) is None:
            user = User.objects.create_user(
                first_name=body["name"],
                username=body["username"],
                password=body["password"],
            )

            user.save()

            Profile.objects.create(
                user=user, fullName="", phone=0, email="", avatar=None
            )
            login(request, user)
        else:
            print(body["password"])
            raise ValidationError("Passwords is not correct")

        return HttpResponse(status=200)
