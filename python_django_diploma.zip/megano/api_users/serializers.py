from django.contrib.auth.models import User
from rest_framework import serializers
from rest_framework.exceptions import ParseError

from api_users.models import Profile, Avatar


class AvatarSerializer(serializers.ModelSerializer):
    class Meta:
        model = Avatar
        fields = ("src", "alt")


class ProfileSerializer(serializers.ModelSerializer):
    avatar = AvatarSerializer()

    class Meta:
        model = Profile
        fields = ("fullName", "email", "phone", "avatar")


class ChangePasswordSerializer(serializers.ModelSerializer):
    currentPassword = serializers.CharField(write_only=True)
    newPassword = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ("currentPassword", "newPassword")

    def validate(self, attrs):
        user = self.instance
        if not user.check_password(attrs["currentPassword"]):
            raise ParseError("Текущий пароль неверен!")
        return attrs

    def update(self, instance, validated_data):
        instance.set_password(validated_data["newPassword"])
        instance.save()
        return instance
