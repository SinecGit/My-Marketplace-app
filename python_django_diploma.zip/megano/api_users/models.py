from django.db import models
from django.contrib.auth.models import User


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    fullName = models.CharField(max_length=100, verbose_name="ФИО", blank=False)
    email = models.EmailField(max_length=100, blank=False)
    phone = models.DecimalField(max_digits=10, decimal_places=0, blank=True, default=0)
    avatar = models.ForeignKey(
        "Avatar", on_delete=models.CASCADE, default="", null=True, verbose_name="Аватар"
    )

    class Meta:
        verbose_name_plural = "Профили"
        verbose_name = "Профиль"

    def __str__(self):
        return str(self.fullName)


class Avatar(models.Model):
    src = models.ImageField(upload_to="images/", blank=True, verbose_name="Аватар")
    alt = models.CharField(max_length=100, blank=True)

    class Meta:
        verbose_name_plural = "Аватары"
        verbose_name = "Аватар"

    def __str__(self):
        return str(self.alt)
