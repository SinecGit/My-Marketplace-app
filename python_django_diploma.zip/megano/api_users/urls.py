from django.urls import path
from api_users import views

urlpatterns = [
    path("", views.ProfileAPIView.as_view(), name="profile"),
    path("/avatar", views.avatar_change, name="avatar"),
    path("password", views.ChangePasswordView.as_view(), name="passwd_ch"),
]
