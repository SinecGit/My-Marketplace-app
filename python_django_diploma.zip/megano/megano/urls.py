from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from api_users.views import signin, signup, signout
from api_product.views import TagsAPIView
from api_orders.views import BasketAPIView, payment


urlpatterns = [
    path("", include("frontend.urls")),
    path("admin/", admin.site.urls),
    path("api/sign-in", signin, name="signIn"),
    path("api/sign-out", signout, name="signout"),
    path("api/sign-up", signup, name="signup"),
    path("api/profile", include("api_users.urls")),
    path("api/tags", TagsAPIView.as_view(), name="tags"),
    path("api/product/", include("api_product.urls")),
    path("api/", include("api_product.urls")),
    path("api/basket", BasketAPIView.as_view(), name="view_basket"),
    path("api/order/", include("api_orders.urls")),
    path("api/orders", include("api_orders.urls")),
    path("api/payment/<int:id>", payment, name="view_payment"),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
