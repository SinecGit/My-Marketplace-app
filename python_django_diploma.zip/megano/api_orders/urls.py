from django.urls import path
from .views import OrdersAPIView, OrderAPIView

urlpatterns = [
    path("", OrdersAPIView.as_view(), name="view_orders"),
    path("<int:pk>", OrderAPIView.as_view(), name="view_order"),
]
