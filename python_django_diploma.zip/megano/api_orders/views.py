import json
import re
from datetime import datetime

from django.db import transaction
from django.http import JsonResponse, HttpResponse
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Orders, Basket
from .serializers import GetOrdersSerializer, BasketItemsSerializer
from django.contrib import messages

from api_product.models import Product, Sale


class OrderAPIView(generics.RetrieveUpdateAPIView):
    queryset = Orders.objects.all()
    serializer_class = GetOrdersSerializer

    def post(self, request, *args, **kwargs):
        with transaction.atomic():
            obj = Orders.objects.get(id=kwargs["pk"])
            obj.fullName = request.data["fullName"]
            obj.email = request.data["email"]
            obj.phone = request.data["phone"]
            obj.deliveryType = request.data["deliveryType"]
            obj.paymentType = "online"
            obj.totalCost = request.data["basketCount"]["price"]
            obj.status = "accepted"
            obj.city = request.data["city"]
            obj.address = request.data["address"]
            obj.save()
            # Basket.objects.all().delete()

            data = {"orderId": obj.id}
        return JsonResponse(data)


class OrdersAPIView(APIView):
    def get(self, request):
        orders_list = Orders.objects.prefetch_related("products").filter(
            user=self.request.user, status="paid"
        )
        item_orders_list = GetOrdersSerializer(orders_list, many=True).data
        return Response(item_orders_list)

    def post(self, request):
        Orders.objects.filter(status="not_accepted").delete()
        products_in_basket = Basket.objects.all()

        if not request.user.is_authenticated:
            raise Exception("Только авторизованные пользователи!")

            # user_full_name = 'AnonymousUser'
            # user_email = 'not indicated'
            # user_phone = 'not indicated'
            # user_id = 'AnonymousUser'
        else:
            user_full_name = request.user.profile.fullName
            user_email = request.user.profile.email
            user_phone = request.user.profile.phone
            user_id = request.user

        item_orders = Orders.objects.create(
            user=user_id,
            createdAt=datetime.strftime(datetime.now(), "%Y-%m-%d %H:%M"),
            fullName=user_full_name,
            email=user_email,
            phone=user_phone,
            deliveryType="ordinary",
            paymentType="online",
            totalCost=0,
            status="not_accepted",
            city="",
            address="",
        )
        item_orders.products.add(*[item.product.id for item in products_in_basket])
        item_orders.price = {
            str(item.product.id): str(item.price) for item in products_in_basket
        }
        item_orders.count = {
            str(item.product.id): str(item.count) for item in products_in_basket
        }
        item_orders.save()

        data = {"orderId": item_orders.id}
        return JsonResponse(data)


class BasketAPIView(APIView):
    def get(self, request):
        product_list = Basket.objects.all()
        item_product_list = BasketItemsSerializer(product_list, many=True).data
        return Response(item_product_list)

    def post(self, request):
        product = Product.objects.get(id=request.data["id"])
        baskets = Basket.objects.filter(product=product)

        if request.data["count"] > product.count:
            messages.add_message(request, messages.INFO, "Hello world.")

        if not baskets.exists():
            in_sale = Sale.objects.filter(active=True, title=product)
            if in_sale:
                cart_price = product.price - in_sale.first().price
            else:
                cart_price = product.price

            Basket.objects.create(
                product=product, price=cart_price, count=request.data["count"]
            )
        else:
            baskets = baskets.first()
            baskets.count += request.data["count"]
            baskets.save()

        product_list = Basket.objects.all()
        item_product_list = BasketItemsSerializer(product_list, many=True).data

        return Response(item_product_list)

    def delete(self, request):
        if request.data["count"] == 0:
            Basket.objects.get(product=request.data["id"]).delete()
        else:
            baskets = Basket.objects.filter(product=request.data["id"]).first()
            baskets.count -= request.data["count"]
            baskets.save()

        product_list = Basket.objects.all()
        item_product_list = BasketItemsSerializer(product_list, many=True).data

        return Response(item_product_list)

    def clear_basket() -> None:
        Basket.objects.all().delete()


def payment(request, id):
    if request.method == "POST":
        body = json.loads(request.body)
        if re.fullmatch(r"\d{16}", body["number"]):
            if (re.fullmatch(r"\d\d", body["month"])) and (
                1 <= int(body["month"]) <= 12
            ):
                if (re.fullmatch(r"\d\d", body["year"])) and (
                    datetime.now().year % 100
                    <= int(body["year"])
                    < datetime.now().year % 100 + 5
                ):
                    if (re.fullmatch(r"\d{3}", body["code"])) and (
                        int(body["code"]) > 0
                    ):
                        print("Оплата заказа {} успешно выполнена".format(id))
                        BasketAPIView.clear_basket()
                        order = Orders.objects.get(id=id)
                        order.status = "paid"
                        order.save()
                        return HttpResponse(status=200)
                    else:
                        print("Ошибка: Не верно введен CVV код!")
                else:
                    print("Ошибка: Не верно указан год!")
            else:
                print("Ошибка: Не верно указан месяц!")
        else:
            print("Ошибка: Не верно указан номер карты!")

    return HttpResponse(status=403)
