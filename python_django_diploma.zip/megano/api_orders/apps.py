from django.apps import AppConfig


class ApiOrdersConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "api_orders"
