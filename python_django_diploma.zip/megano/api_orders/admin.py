from django.contrib import admin
from .models import Orders, Basket


@admin.register(Basket)
class BasketAdmin(admin.ModelAdmin):
    readonly_fields = ("price",)


@admin.register(Orders)
class OrdersAdmin(admin.ModelAdmin):
    filter_horizontal = ("products",)
    search_fields = ("fullName",)
    list_display = ("fullName", "status")
