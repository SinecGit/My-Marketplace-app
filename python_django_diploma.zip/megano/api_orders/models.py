from django.contrib.auth.models import User
from django.db import models
from api_product.models import Product


class Orders(models.Model):
    payment_online = "online"
    payment_cash = "cash"
    payment = [
        (payment_online, "онлайн"),
        (payment_cash, "наличные"),
    ]

    delivery_free = "free"
    delivery_paid = "paid"
    delivery = [
        (delivery_free, "бесплатная"),
        (delivery_paid, "платная"),
    ]
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, verbose_name="Пользователь"
    )
    createdAt = models.DateTimeField(auto_now_add=True, verbose_name="Дата создания")
    fullName = models.CharField(
        max_length=100, blank=False, verbose_name="Название заказа"
    )
    email = models.EmailField(max_length=254)
    phone = models.DecimalField(max_digits=11, decimal_places=0, blank=True, default=0)
    deliveryType = models.CharField(
        max_length=4,
        choices=delivery,
        default=delivery_free,
        verbose_name="Тип доставки",
    )
    paymentType = models.CharField(
        max_length=6, choices=payment, default=payment_online, verbose_name="Вид оплаты"
    )
    totalCost = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        blank=False,
        verbose_name="Стоимость",
    )
    status = models.CharField(max_length=100, blank=False, verbose_name="Статус заказа")
    city = models.CharField(max_length=100, blank=False, verbose_name="Город")
    address = models.CharField(max_length=100, blank=False, verbose_name="Адрес")
    products = models.ManyToManyField(
        Product, blank=True, verbose_name="Товары", related_name="getOrdersProducts"
    )
    price = models.JSONField(default=dict, blank=False, verbose_name="Цена")
    count = models.JSONField(default=dict, blank=False, verbose_name="Количество")

    class Meta:
        verbose_name_plural = "Заказы"
        verbose_name = "Заказ"

    def __str__(self):
        return f"{self.fullName}"


class Basket(models.Model):
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        blank=False,
        verbose_name="Товар",
        related_name="view_product",
    )
    price = models.DecimalField(
        max_digits=10, decimal_places=2, default=0, blank=False, verbose_name="Цена"
    )
    count = models.PositiveIntegerField(
        default=0, blank=True, verbose_name="Количество"
    )
    date = models.DateTimeField(auto_now_add=True, verbose_name="Дата")

    class Meta:
        verbose_name = "Корзина"
        verbose_name_plural = "Корзины"

    def __str__(self):
        return str(self.product)
