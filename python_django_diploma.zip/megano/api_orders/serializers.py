from rest_framework import serializers

from api_product.models import Product
from api_product.serializers import ProductImagesSerializer, TagsSerializer
from megano.settings import TIME_ZONE
from .models import Orders, Basket
from datetime import datetime


class OrderProductsSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField(method_name="get_product_images")
    tags = serializers.SerializerMethodField(method_name="get_product_tags")
    reviews = serializers.SerializerMethodField(method_name="get_product_reviews")

    class Meta:
        model = Product
        fields = (
            "id",
            "category",
            "price",
            "count",
            "date",
            "title",
            "description",
            "freeDelivery",
            "images",
            "tags",
            "reviews",
            "rating",
        )

    def get_product_images(self, obj):
        queryset = obj.image_product.all()
        return [ProductImagesSerializer(item).data for item in queryset]

    def get_product_tags(self, obj):
        queryset = obj.tags.values("id", "name")
        return [item for item in queryset]

    def get_product_reviews(self, obj):
        queryset = obj.product_reviews.all()
        return queryset.count()

    def get_date(self, obj):
        return datetime.strftime(
            obj.date, "%a %b %d %Y %H:%M:%S %Z %z (" + TIME_ZONE + ")"
        )


class GetOrdersSerializer(serializers.ModelSerializer):
    products = serializers.SerializerMethodField(method_name="get_products")
    createdAt = serializers.SerializerMethodField(method_name="get_createdAt")

    class Meta:
        model = Orders
        fields = (
            "id",
            "createdAt",
            "fullName",
            "email",
            "phone",
            "deliveryType",
            "paymentType",
            "totalCost",
            "status",
            "city",
            "address",
            "products",
            "price",
            "count",
        )

    def get_products(self, obj):
        queryset = obj.products.all()
        list_products = []
        for item in queryset:
            product_in_order = OrderProductsSerializer(item).data
            product_in_order["price"] = float(obj.price[str(item.id)])
            product_in_order["count"] = float(obj.count[str(item.id)])
            list_products.append(product_in_order)
        # return [OrderProductsSerializer(item).data for item in queryset]
        return list_products

    def get_createdAt(self, obj):
        return datetime.strftime(obj.createdAt, "%Y-%m-%d %H:%M")


class BasketProductsSerializer(serializers.ModelSerializer):
    product = serializers.SerializerMethodField(method_name="get_product")

    class Meta:
        model = Orders
        fields = ("products",)

    def get_product(self, obj):
        queryset = OrderProductsSerializer(data=obj.product, many=True)
        return queryset


class BasketItemsSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField(method_name="get_product_images")
    tags = serializers.SerializerMethodField(method_name="get_product_tags")
    reviews = serializers.SerializerMethodField(method_name="get_product_reviews")

    id = serializers.SerializerMethodField(method_name="get_id")
    category = serializers.SerializerMethodField(method_name="get_category")
    title = serializers.SerializerMethodField(method_name="get_title")
    description = serializers.SerializerMethodField(method_name="get_description")
    freeDelivery = serializers.SerializerMethodField(method_name="get_freedelivery")
    rating = serializers.SerializerMethodField(method_name="get_rating")
    date = serializers.SerializerMethodField(method_name="get_date")

    class Meta:
        model = Basket
        fields = (
            "id",
            "category",
            "price",
            "count",
            "date",
            "title",
            "description",
            "freeDelivery",
            "images",
            "tags",
            "reviews",
            "rating",
        )

    def get_product_images(self, obj):
        queryset = obj.product.image_product.all()
        return [ProductImagesSerializer(item).data for item in queryset]

    def get_product_tags(self, obj):
        queryset = obj.product.tags.values()
        return [TagsSerializer(item).data for item in queryset]

    def get_product_reviews(self, obj):
        queryset = obj.product.product_reviews.all().count()
        return queryset

    def get_id(self, obj):
        return obj.product.id

    def get_category(self, obj):
        return obj.product.category.id

    def get_title(self, obj):
        return obj.product.title

    def get_description(self, obj):
        return obj.product.description

    def get_freedelivery(self, obj):
        return obj.product.freeDelivery

    def get_rating(self, obj):
        return obj.product.rating

    def get_date(self, obj):
        return datetime.strftime(
            obj.date, "%a %b %d %Y %H:%M:%S %Z %z (" + TIME_ZONE + ")"
        )
