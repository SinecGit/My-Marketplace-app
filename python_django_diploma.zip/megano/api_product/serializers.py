from datetime import datetime
from rest_framework import serializers
from .models import (
    Reviews,
    Specifications,
    ProductImages,
    Tags,
    Category,
    Images,
    Product,
    Sale,
)


class ProductImagesSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImages
        fields = ("src", "alt")


class SpecSerializer(serializers.ModelSerializer):
    class Meta:
        model = Specifications
        fields = ("name", "value")


class ReviewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Reviews
        fields = ("author", "email", "text", "rate", "date")


class ProductSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField(method_name="get_product_images")
    tags = serializers.SerializerMethodField(method_name="get_product_tags")
    reviews = serializers.SerializerMethodField(method_name="get_product_reviews")
    specifications = serializers.SerializerMethodField(method_name="get_product_specs")

    class Meta:
        model = Product
        fields = (
            "id",
            "category",
            "price",
            "count",
            "date",
            "title",
            "description",
            "fullDescription",
            "freeDelivery",
            "images",
            "tags",
            "reviews",
            "specifications",
            "rating",
        )

    def get_product_images(self, obj):
        queryset = obj.image_product.all()
        return [ProductImagesSerializer(item).data for item in queryset]

    def get_product_tags(self, obj):
        queryset = obj.tags.values("id", "name")
        return [item for item in queryset]

    def get_product_reviews(self, obj):
        queryset = obj.product_reviews.all()
        return [ReviewsSerializer(item).data for item in queryset]

    def get_product_specs(self, obj):
        queryset = obj.specifications.all()
        return [SpecSerializer(item).data for item in queryset]


class TagsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tags
        fields = ("id", "name")


class ImagesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Images
        fields = ("src", "alt")


class SubCategorySerializer(serializers.Serializer):
    id = serializers.IntegerField()
    title = serializers.CharField(max_length=100)
    image = ImagesSerializer()


class CategorySerializer(serializers.ModelSerializer):
    image = ImagesSerializer()
    subcategories = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ("id", "title", "image", "subcategories")

    def get_subcategories(self, obj):
        # queryset = SubCategory.objects.filter(Category_id=obj.id).all()
        queryset = obj.subcategories.all()
        return [SubCategorySerializer(item).data for item in queryset]


class ProductItemsSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField(method_name="get_product_images")
    tags = serializers.SerializerMethodField(method_name="get_product_tags")
    reviews = serializers.SerializerMethodField(method_name="get_product_reviews")

    class Meta:
        model = Product
        fields = (
            "id",
            "category",
            "price",
            "count",
            "date",
            "title",
            "description",
            "fullDescription",
            "freeDelivery",
            "images",
            "tags",
            "reviews",
            "rating",
        )

    def get_product_images(self, obj):
        queryset = obj.image_product.all()
        return [ProductImagesSerializer(item).data for item in queryset]

    def get_product_tags(self, obj):
        queryset = obj.tags.values()
        return [TagsSerializer(item).data for item in queryset]

    def get_product_reviews(self, obj):
        queryset = obj.product_reviews.all().count()
        return queryset


class SaleProductSerializer(serializers.ModelSerializer):
    images = serializers.SerializerMethodField(method_name="get_product_images")
    dateFrom = serializers.SerializerMethodField(method_name="get_data_from")
    dateTo = serializers.SerializerMethodField(method_name="get_data_to")
    title = serializers.SerializerMethodField(method_name="get_title")
    salePrice = serializers.SerializerMethodField(method_name="get_sale_price")
    price = serializers.SerializerMethodField(method_name="get_price")
    id = serializers.SerializerMethodField(method_name="get_id")

    class Meta:
        model = Sale
        fields = ("id", "price", "salePrice", "dateFrom", "dateTo", "title", "images")

    def get_product_images(self, obj):
        queryset = obj.title.image_product.all()
        return [ProductImagesSerializer(item).data for item in queryset]

    def get_data_from(self, obj):
        return datetime.strftime(obj.dateFrom, "%m-%d")

    def get_data_to(self, obj):
        return datetime.strftime(obj.dateTo, "%m-%d")

    def get_title(self, obj):
        return obj.title.title

    def get_sale_price(self, obj):
        return obj.title.price - obj.price

    def get_price(self, obj):
        return obj.title.price

    def get_id(self, obj):
        return obj.title.id
