from django import forms
from django.core.exceptions import ValidationError
from django.contrib import admin
from django.utils.safestring import mark_safe

from .models import (
    Specifications,
    Reviews,
    Tags,
    Category,
    Product,
    ProductImages,
    Images,
    Sale,
)


@admin.register(Specifications)
class SpecificationsAdmin(admin.ModelAdmin):
    pass


@admin.register(Reviews)
class ReviewsAdmin(admin.ModelAdmin):
    pass


@admin.register(Tags)
class TagsAdmin(admin.ModelAdmin):
    pass


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    pass


@admin.register(Images)
class ImagesAdmin(admin.ModelAdmin):
    pass


class TagsInline(admin.TabularInline):
    model = Tags
    extra = 0


class ReviewsInline(admin.TabularInline):
    model = Reviews
    extra = 0


class SpecsInline(admin.TabularInline):
    model = Specifications
    extra = 0


class ProductImagesInline(admin.TabularInline):
    model = ProductImages
    extra = 0
    fields = ["src", "alt", "preview"]
    readonly_fields = ["preview"]

    def preview(self, obj):
        return mark_safe(f'<img src="{obj.src.url}" style="max-height: 150px;">')


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    save_on_top = True
    list_display = (
        "title",
        "reviews",
    )
    inlines = [ProductImagesInline, ReviewsInline, SpecsInline]
    exclude = ("rating", "reviews")
    filter_horizontal = ("tags",)


class SaleAdminForm(forms.ModelForm):
    def clean(self):
        cleaned_data = super().clean()

        if cleaned_data.get("active"):
            obj = Sale.objects.filter(title=cleaned_data.get("title").id, active=True)
            if obj.count() == 0:
                return cleaned_data
            if obj.count() == 1 and obj.first().id == self.instance.id:
                return cleaned_data
            else:
                raise ValidationError(
                    "На выбранный товар еще действует текущая скидка!"
                )

        return cleaned_data


@admin.register(Sale)
class SaleAdmin(admin.ModelAdmin):
    form = SaleAdminForm
    list_display = ("title", "price", "dateFrom", "dateTo", "active")
    fields = ("title", "price", "dateFrom", "dateTo", "active")
    search_fields = ("title__title",)
