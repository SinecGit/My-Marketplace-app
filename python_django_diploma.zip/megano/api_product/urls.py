from django.urls import path
from api_product import views

urlpatterns = [
    path("<int:pk>", views.ProductAPIView.as_view(), name="view_product"),
    path("<int:pk>/reviews", views.ReviewProductAPIView.as_view(), name="reviews"),
    path("catalog", views.CatalogAPIView.as_view(), name="get_catalog"),
    path("categories", views.CategoryAPIView.as_view(), name="get_categories"),
    path(
        "products/popular",
        views.PopLimProductAPIView.as_view(
            mode_sort="Product.objects.filter(rating__gt=3)[:8]"
        ),
        name="product_popular",
    ),
    path(
        "products/limited",
        views.PopLimProductAPIView.as_view(
            mode_sort="Product.objects.filter(count__lte=2)[:16]"
        ),
        name="product_limited",
    ),
    path(
        "banners",
        views.PopLimProductAPIView.as_view(
            mode_sort="Product.objects.filter(rating__gte=3.5)[:3]"
        ),
        name="products_banners",
    ),
    path("sales", views.SaleProductAPIView.as_view(), name="sale_products"),
]
