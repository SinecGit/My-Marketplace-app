from django.core.paginator import Paginator
from django.db.models import Avg, Count
from django.db import transaction
from rest_framework import generics
from rest_framework.response import Response
from rest_framework.views import APIView

from .models import Reviews, Tags, Product, Category, Sale
from .serializers import (
    ProductSerializer,
    ReviewsSerializer,
    TagsSerializer,
    CategorySerializer,
    ProductItemsSerializer,
    SaleProductSerializer,
)


class ProductAPIView(generics.RetrieveAPIView):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer


class ReviewProductAPIView(APIView):
    def post(self, request, *args, **kwargs):
        item_review = Reviews.objects.create(
            author=request.data["author"],
            email=request.data["email"],
            text=request.data["text"],
            rate=request.data["rate"],
            product=Product.objects.get(pk=kwargs["pk"]),
        )

        with transaction.atomic():
            product_item = Product.objects.get(pk=kwargs["pk"])
            set_param_product = Reviews.objects.filter(product=kwargs["pk"]).aggregate(
                Avg("rate"), Count("rate")
            )
            # product_item.rating = round(Reviews.objects.filter(product=kwargs['pk']).aggregate(Avg('rate'))['rate__avg'], 1)
            product_item.rating = round(set_param_product["rate__avg"], 1)
            product_item.reviews = set_param_product["rate__count"]
            product_item.save()

        all_reviews = Reviews.objects.filter(product=kwargs["pk"])
        return Response(
            [ReviewsSerializer(item_reviews).data for item_reviews in all_reviews]
        )


class TagsAPIView(generics.ListAPIView):
    queryset = Tags.objects.all()
    serializer_class = TagsSerializer


class CategoryAPIView(generics.ListAPIView):
    queryset = Category.objects.all().filter(parent=None)
    serializer_class = CategorySerializer


class CatalogAPIView(APIView):
    def get(self, request):
        get_body = request.query_params
        sort_string = get_body["sort"]

        if get_body["sortType"] == "dec":
            sort_string = "-" + get_body["sort"]
        # Фильтр списка товаров по тэгу
        if "tags[]" in get_body:
            product_list = Product.objects.filter(
                tags__in=list(map(int, get_body.getlist("tags[]")))
            ).distinct()
        else:
            product_list = Product.objects.all()

        # Если выбрана категория или подкатегория товаров
        if "category" in get_body:
            if Category.objects.get(id=get_body["category"]).parent:
                # Выбрана подкатегория
                product_list = product_list.filter(
                    category=get_body["category"],
                    title__contains=get_body["filter[name]"],
                    price__range=(
                        float(get_body["filter[minPrice]"]),
                        float(get_body["filter[maxPrice]"]),
                    ),
                    freeDelivery=eval(get_body["filter[freeDelivery]"].capitalize()),
                ).order_by(sort_string)

            else:
                # Выбрана категория
                product_list = product_list.filter(
                    category__parent=get_body["category"],
                    title__contains=get_body["filter[name]"],
                    price__range=(
                        float(get_body["filter[minPrice]"]),
                        float(get_body["filter[maxPrice]"]),
                    ),
                    freeDelivery=eval(get_body["filter[freeDelivery]"].capitalize()),
                ).order_by(sort_string)
        # Если выбран каталог целиком
        else:
            product_list = product_list.filter(
                title__contains=get_body["filter[name]"],
                price__range=(
                    float(get_body["filter[minPrice]"]),
                    float(get_body["filter[maxPrice]"]),
                ),
                freeDelivery=eval(get_body["filter[freeDelivery]"].capitalize()),
            ).order_by(sort_string)

        paginator = Paginator(product_list, per_page=3)
        product_paginator = paginator.page(get_body["currentPage"])
        item_product_list = ProductItemsSerializer(product_paginator, many=True).data

        return Response(
            {
                "items": item_product_list,
                "currentPage": get_body["currentPage"],
                "lastPage": paginator.num_pages,
            }
        )


class PopLimProductAPIView(APIView):
    mode_sort = ""

    def get(self, request):
        # product_list = Catalog.objects.filter(items__rating__gt=3)
        # eval = Catalog.objects.filter(items__rating__gt=3) из urls
        product_list = eval(self.mode_sort)
        # item_product_list = [ProductItemsSerializer(item).data for item in product_list]
        item_product_list = ProductItemsSerializer(product_list, many=True).data

        return Response(item_product_list)


class SaleProductAPIView(APIView):
    def get(self, request):
        get_body = request.query_params
        product_list = Sale.objects.select_related("title").filter(active=True)

        sale_paginator = Paginator(product_list, per_page=3)
        product_paginator = sale_paginator.page(get_body["currentPage"])

        item_product_list = SaleProductSerializer(product_paginator, many=True).data

        return Response(
            {
                "items": item_product_list,
                "currentPage": get_body["currentPage"],
                "lastPage": sale_paginator.num_pages,
            }
        )
