from django.db import models


# БД изображений для каталога (категорий и подкатегорий)
class Images(models.Model):
    src = models.ImageField(
        upload_to="images/catalog/", null=True, blank=True, verbose_name="Изображение"
    )
    alt = models.CharField(max_length=100, null=True, blank=True)

    class Meta:
        verbose_name_plural = "Изображения"
        verbose_name = "Изображение"

    def __str__(self):
        return str(self.alt)


class Category(models.Model):
    title = models.CharField(
        max_length=100, blank=False, null=False, verbose_name="Категория"
    )
    image = models.ForeignKey(
        Images, on_delete=models.PROTECT, blank=True, verbose_name="Изображение"
    )
    parent = models.ForeignKey(
        "self",
        on_delete=models.PROTECT,
        blank=True,
        null=True,
        related_name="subcategories",
        verbose_name="Подкатегория",
    )

    class Meta:
        verbose_name_plural = "Категории"
        verbose_name = "Категория"

    def __str__(self):
        return "> " + str(self.title) if self.parent is None else str(self.title)


class Tags(models.Model):
    name = models.CharField(max_length=50, verbose_name="Имя тэга")

    class Meta:
        verbose_name = "Тэг"
        verbose_name_plural = "Тэги"

    def __str__(self):
        return str(self.name)


class Product(models.Model):
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, blank=False, verbose_name="Категория"
    )
    price = models.DecimalField(
        max_digits=10, decimal_places=2, default=0, blank=False, verbose_name="Цена"
    )
    count = models.PositiveIntegerField(
        default=0, blank=True, verbose_name="Количество"
    )
    sale = models.BooleanField(default=False, blank=True, verbose_name="Распродажа")
    date = models.DateTimeField(auto_now_add=True, verbose_name="Дата")
    title = models.CharField(
        max_length=100, blank=False, db_index=True, verbose_name="Товар/Продукт"
    )
    description = models.TextField(max_length=150, blank=True, verbose_name="Описание")
    fullDescription = models.TextField(
        max_length=250, blank=True, verbose_name="Полное описание"
    )
    freeDelivery = models.BooleanField(
        default=False, blank=True, verbose_name="Бесплатная доставка"
    )
    rating = models.DecimalField(
        max_digits=2, decimal_places=1, default=0, blank=False, verbose_name="Рейтинг"
    )
    reviews = models.PositiveIntegerField(default=0, blank=True, verbose_name="Отзывы")
    tags = models.ManyToManyField(
        Tags, blank=True, verbose_name="Тэги", related_name="get_tags"
    )

    class Meta:
        verbose_name_plural = "Товары"
        verbose_name = "Товар"

    def __str__(self):
        return str(self.title)


class Sale(models.Model):
    title = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        blank=True,
        verbose_name="Товар",
        related_name="sale_product",
    )
    price = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        default=0,
        blank=False,
        verbose_name="Цена скидки",
    )
    dateFrom = models.DateField(verbose_name="Дата начала")
    dateTo = models.DateField(verbose_name="Дата окончания")
    active = models.BooleanField(default=True, blank=True, verbose_name="Активность")

    class Meta:
        verbose_name_plural = "Распродажи"
        verbose_name = "Распродажа"

    def __str__(self):
        return str(self.title.title)


class Reviews(models.Model):
    author = models.CharField(max_length=100, blank=False, verbose_name="Автор")
    email = models.EmailField(max_length=100, blank=True, verbose_name="Эл. почта")
    text = models.TextField(max_length=250, blank=False, verbose_name="Текст отзыва")
    rate = models.PositiveIntegerField(blank=True, default=1, verbose_name="Оценка")
    date = models.DateTimeField(auto_now_add=True, verbose_name="Дата")
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        blank=True,
        verbose_name="Продукт",
        related_name="product_reviews",
    )

    class Meta:
        verbose_name_plural = "Отзывы"
        verbose_name = "Отзыв"

    def __str__(self):
        return str(self.author)


class Specifications(models.Model):
    name = models.CharField(
        max_length=100, blank=False, null=False, verbose_name="Параметр"
    )
    value = models.CharField(
        max_length=100, blank=False, null=False, verbose_name="Значение"
    )
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        blank=True,
        verbose_name="Продукт",
        related_name="specifications",
    )

    class Meta:
        verbose_name_plural = "Спецификации"
        verbose_name = "Спецификация"

    def __str__(self):
        return str(self.name)


class ProductImages(models.Model):
    src = models.ImageField(
        upload_to="images/product/", null=True, blank=True, verbose_name="Изображение"
    )
    alt = models.CharField(max_length=100, null=True, blank=True)
    product = models.ForeignKey(
        Product,
        on_delete=models.CASCADE,
        blank=True,
        verbose_name="Продукт",
        related_name="image_product",
    )

    class Meta:
        verbose_name_plural = "Изображения"
        verbose_name = "Изображение"

    def __str__(self):
        return str(self.alt)
